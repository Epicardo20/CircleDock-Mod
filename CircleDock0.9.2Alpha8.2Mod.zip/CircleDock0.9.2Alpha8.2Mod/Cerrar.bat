@echo off
:: Registro para verificar que el archivo fue ejecutado
echo [%DATE% %TIME%] Ejecutando cierre de sesión desde Circle Dock >> "%~dp0log_cierre_sesion.txt"

:: Intento 1: Usar ruta absoluta de logoff.exe
%SystemRoot%\System32\logoff.exe >> "%~dp0log_cierre_sesion.txt" 2>&1

:: Intento 2: shutdown como alternativa (por si logoff falla)
shutdown.exe /l >> "%~dp0log_cierre_sesion.txt" 2>&1